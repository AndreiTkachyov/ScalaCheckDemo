package org.scalatest

import org.scalatest.events.Event

object StubReporter extends Reporter {
  def apply(event: Event) {
  }
}
