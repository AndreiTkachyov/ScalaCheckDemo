package org.scalatest.junit;

import org.junit.Test;
import org.junit.Ignore;

import static org.junit.Assert.*;

public class JHappySuite {
    public JHappySuite() {}

  @Test public void verifySomething() {} // Don't do nothin'
}

